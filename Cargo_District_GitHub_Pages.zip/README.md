# Cargo District — Isometric Logistics Tycoon

A small browser game for mobile and desktop. The gameplay is in `index.html`; there is no build step.

## Deploy on GitHub Pages

1. Create a public GitHub repository called `cargo-district`.
2. Upload `index.html` (and optionally this README) into the repository's root, not inside another folder.
3. Commit files to your `main` branch.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, select **Deploy from a branch**; branch `main` and folder `/(root)`; then **Save**.
6. Open `https://YOUR-USERNAME.github.io/cargo-district/` once Pages shows the site is live.

Do not upload this ZIP directly expecting Pages to run the game. You must extract and upload its `index.html` file.

On iPhone, in Safari tap **Share → Add to Home Screen** to create a shortcut.
